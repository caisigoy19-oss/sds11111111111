export type GestureType = 'Closed_Fist' | 'Open_Palm' | 'None' | 'Loading';

export interface GestureState {
  currentGesture: GestureType;
  confidence: number;
}