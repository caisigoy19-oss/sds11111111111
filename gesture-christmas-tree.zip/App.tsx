import React, { useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { Experience } from './components/Experience';
import { GestureController } from './components/GestureController';
import { GestureType } from './types';
import { Loader } from '@react-three/drei';

const App: React.FC = () => {
  const [gesture, setGesture] = useState<GestureType>('Loading');
  const [photos, setPhotos] = useState<string[]>([]);

  const handleGestureDetected = (detectedGesture: GestureType) => {
    setGesture(detectedGesture);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const newPhotos = Array.from(event.target.files).map(file => URL.createObjectURL(file as Blob));
      setPhotos(prev => [...prev, ...newPhotos]);
    }
  };

  const isScattered = gesture === 'Open_Palm';

  return (
    <div className="relative w-full h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      
      {/* 3D Scene Layer */}
      <div className="absolute inset-0 z-10">
        <Canvas
          shadows
          camera={{ position: [0, 2, 18], fov: 45 }}
          dpr={[1, 2]} // Optimize pixel ratio
        >
          <Experience isScattered={isScattered} photos={photos} />
        </Canvas>
      </div>

      {/* UI Overlay Layer */}
      <div className="absolute inset-0 z-20 pointer-events-none flex flex-col justify-between p-6">
        
        {/* Header */}
        <div className="text-center mt-4">
          <h1 className="text-4xl md:text-6xl text-red-500 font-holiday font-bold drop-shadow-[0_2px_2px_rgba(255,255,255,0.8)]">
            Merry Christmas
          </h1>
          <p className="text-slate-300 mt-2 text-sm md:text-base max-w-md mx-auto bg-black/30 p-2 rounded-lg backdrop-blur-sm border border-white/10">
            Show your hand to the camera!
            <br />
            <span className="text-green-400 font-bold">Open Hand 🖐</span> = Scatter Bells
            <br />
            <span className="text-red-400 font-bold">Fist ✊</span> = Assemble Tree
          </p>
        </div>

        {/* Bottom Controls Container */}
        <div className="flex flex-col md:flex-row items-end justify-between w-full pointer-events-auto">
            
            {/* Upload Button (Bottom Left) */}
            <div className="mb-4 md:mb-0">
                <label className="cursor-pointer group flex items-center gap-2 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 rounded-lg px-4 py-3 transition-all">
                    <div className="bg-red-500 p-2 rounded-full shadow-lg group-hover:scale-110 transition-transform">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                    </div>
                    <div className="flex flex-col">
                         <span className="text-white font-bold text-sm">Upload Photos</span>
                         <span className="text-slate-300 text-xs">Add memories to the tree</span>
                    </div>
                    <input 
                        type="file" 
                        multiple 
                        accept="image/*" 
                        className="hidden" 
                        onChange={handleFileUpload}
                    />
                </label>
            </div>

            {/* Webcam Container (Bottom Right) */}
            <div className="pointer-events-auto">
               <GestureController onGestureDetected={handleGestureDetected} />
            </div>

        </div>

        {/* Current State Indicator */}
        <div className="absolute top-1/2 left-0 w-full text-center pointer-events-none opacity-20 z-0">
             <span className="text-9xl font-bold text-white tracking-widest uppercase">
               {gesture === 'Loading' ? 'Loading AI...' : gesture === 'None' ? 'No Hand' : gesture === 'Open_Palm' ? 'SCATTER' : 'ASSEMBLE'}
             </span>
        </div>
      </div>
      
      <Loader />
    </div>
  );
};

export default App;