export const BELL_COUNT = 400;
export const TREE_HEIGHT = 12;
export const TREE_RADIUS_BASE = 4;
export const SCATTER_RADIUS = 25;

// MediaPipe Model Asset
export const GESTURE_RECOGNIZER_TASK_URL = "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task";