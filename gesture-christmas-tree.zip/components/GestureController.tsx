import React, { useEffect, useRef, useState } from 'react';
import { FilesetResolver, GestureRecognizer } from '@mediapipe/tasks-vision';
import { GESTURE_RECOGNIZER_TASK_URL } from '../constants';
import { GestureType } from '../types';

interface GestureControllerProps {
  onGestureDetected: (gesture: GestureType) => void;
}

export const GestureController: React.FC<GestureControllerProps> = ({ onGestureDetected }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const gestureRecognizerRef = useRef<GestureRecognizer | null>(null);
  const requestRef = useRef<number>(0);
  const [loading, setLoading] = useState(true);

  // Initialize MediaPipe Gesture Recognizer
  useEffect(() => {
    const initGestures = async () => {
      try {
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.3/wasm"
        );
        
        const recognizer = await GestureRecognizer.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: GESTURE_RECOGNIZER_TASK_URL,
            delegate: "GPU"
          },
          runningMode: "VIDEO",
          numHands: 1
        });
        
        gestureRecognizerRef.current = recognizer;
        setLoading(false);
        onGestureDetected('None'); // Ready
      } catch (err) {
        console.error("Error initializing MediaPipe:", err);
        setError("Failed to load AI model.");
        setLoading(false);
      }
    };

    initGestures();
  }, [onGestureDetected]);

  // Start Camera
  useEffect(() => {
    const startCamera = async () => {
      if (!loading && gestureRecognizerRef.current && videoRef.current) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          videoRef.current.srcObject = stream;
          videoRef.current.addEventListener('loadeddata', predictWebcam);
          setIsCameraActive(true);
        } catch (err) {
          console.error("Camera error:", err);
          setError("Please allow camera access.");
        }
      }
    };

    if (!loading && !isCameraActive) {
      startCamera();
    }

    return () => {
       if (videoRef.current && videoRef.current.srcObject) {
         const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
         tracks.forEach(track => track.stop());
       }
       if (requestRef.current) {
         cancelAnimationFrame(requestRef.current);
       }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading]);

  const predictWebcam = () => {
    if (!gestureRecognizerRef.current || !videoRef.current) return;

    const nowInMs = Date.now();
    
    try {
      if (videoRef.current.currentTime > 0 && !videoRef.current.paused && !videoRef.current.ended) {
          const results = gestureRecognizerRef.current.recognizeForVideo(videoRef.current, nowInMs);

          if (results.gestures.length > 0) {
            const categoryName = results.gestures[0][0].categoryName;
            
            if (categoryName === 'Open_Palm') {
              onGestureDetected('Open_Palm');
            } else if (categoryName === 'Closed_Fist') {
              onGestureDetected('Closed_Fist');
            } else {
              // Keep previous state or set to None if purely "None"
              // Often better to stick to last known valid gesture for smoothness, 
              // but here we might want to default back to tree if hand is weird.
              // Let's just log it and do nothing to prevent flickering.
            }
          } else {
            // No hand detected
             // onGestureDetected('None'); 
             // Optional: Don't scatter if hand leaves frame, maybe stay in last state
          }
      }
    } catch (e) {
      console.warn("Prediction error", e);
    }

    requestRef.current = requestAnimationFrame(predictWebcam);
  };

  return (
    <div className="relative group">
      <div className="overflow-hidden rounded-xl border-2 border-white/20 shadow-2xl bg-black w-32 h-24 md:w-48 md:h-36 relative">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover transform scale-x-[-1]" // Mirror effect
        />
        {loading && (
           <div className="absolute inset-0 flex items-center justify-center bg-gray-900 text-white text-xs">
             Loading AI...
           </div>
        )}
        {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-red-900/80 text-white text-xs p-2 text-center">
              {error}
            </div>
        )}
      </div>
      <div className="absolute -top-8 left-0 right-0 text-center opacity-0 group-hover:opacity-100 transition-opacity text-white text-xs bg-black/50 rounded py-1 pointer-events-none">
        Camera Input
      </div>
    </div>
  );
};