import React, { useMemo, useRef, useEffect } from 'react';
import { Vector3, InstancedMesh, Object3D, Color, MathUtils } from 'three';
import { Line } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import { TREE_HEIGHT, TREE_RADIUS_BASE } from '../constants';

interface RibbonsProps {
  isScattered: boolean;
}

const StringLightStrand: React.FC<{ 
    offset: number; 
    isScattered: boolean; 
    bulbCount: number;
    colorTheme: 'warm' | 'color';
}> = ({ offset, isScattered, bulbCount, colorTheme }) => {
    
    const bulbsRef = useRef<InstancedMesh>(null);
    const dummy = useMemo(() => new Object3D(), []);
    
    // Arrays for bulb positions
    const bulbTargets = useMemo(() => new Float32Array(bulbCount * 3), [bulbCount]);
    const bulbScatters = useMemo(() => new Float32Array(bulbCount * 3), [bulbCount]);
    const bulbCurrent = useMemo(() => new Float32Array(bulbCount * 3), [bulbCount]);
    const bulbColors = useMemo(() => new Float32Array(bulbCount * 3), [bulbCount]);

    // Helper to calculate path points (used for bulbs placement)
    const getPathPoints = (scattered: boolean) => {
        const pts: Vector3[] = [];
        const turns = 7;
        const pointsPerTurn = 15;
        const totalPoints = turns * pointsPerTurn;
        
        for (let i = 0; i <= totalPoints; i++) {
            const t = i / totalPoints;
            const y = t * TREE_HEIGHT;
            const baseR = MathUtils.lerp(TREE_RADIUS_BASE + 0.6, 0.2, t);
            const r = scattered ? baseR * 4 + (Math.sin(t * 10) * 2) : baseR;
            
            const theta = t * Math.PI * 2 * turns + offset;
            const droop = scattered ? 0 : Math.sin(t * turns * Math.PI * 2) * 0.1;

            pts.push(new Vector3(
                r * Math.cos(theta),
                y - droop,
                r * Math.sin(theta)
            ));
        }
        return pts;
    };

    // Initialize Bulbs
    useEffect(() => {
        const points = getPathPoints(false); // Tree shape
        const scatterPoints = getPathPoints(true); // Scatter shape

        // Sample points for bulbs
        for (let i = 0; i < bulbCount; i++) {
            const t = i / (bulbCount - 1);
            const index = Math.floor(t * (points.length - 1));
            const p = points[index];
            const sp = scatterPoints[index];
            const noise = 2.0;
            
            bulbTargets[i*3] = p.x;
            bulbTargets[i*3+1] = p.y;
            bulbTargets[i*3+2] = p.z;
            
            bulbScatters[i*3] = sp.x + (Math.random()-0.5)*noise;
            bulbScatters[i*3+1] = sp.y + (Math.random()-0.5)*noise;
            bulbScatters[i*3+2] = sp.z + (Math.random()-0.5)*noise;

            bulbCurrent[i*3] = p.x;
            bulbCurrent[i*3+1] = p.y;
            bulbCurrent[i*3+2] = p.z;

            // Colors
            const c = new Color();
            if (colorTheme === 'warm') {
                 c.setHSL(0.1 + Math.random() * 0.05, 1, 0.6); 
            } else {
                 const r = Math.random();
                 if (r < 0.25) c.set('#ff0000'); 
                 else if (r < 0.5) c.set('#00ff00');
                 else if (r < 0.75) c.set('#0000ff');
                 else c.set('#ffaa00');
            }
            bulbColors[i*3] = c.r * 5; 
            bulbColors[i*3+1] = c.g * 5;
            bulbColors[i*3+2] = c.b * 5;
        }
        
        if (bulbsRef.current) {
             for (let i = 0; i < bulbCount; i++) {
                 dummy.position.set(0,0,0);
                 const c = new Color(bulbColors[i*3]/5, bulbColors[i*3+1]/5, bulbColors[i*3+2]/5);
                 bulbsRef.current.setColorAt(i, c);
             }
             bulbsRef.current.instanceColor!.needsUpdate = true;
        }

    }, [bulbCount, colorTheme, offset, dummy]);


    // Animation Loop
    useFrame((state, delta) => {
       if (bulbsRef.current) {
            const lambda = 3;
            const dest = isScattered ? bulbScatters : bulbTargets;

            for(let i=0; i<bulbCount; i++) {
                const ix = i*3;
                bulbCurrent[ix] = MathUtils.damp(bulbCurrent[ix], dest[ix], lambda, delta);
                bulbCurrent[ix+1] = MathUtils.damp(bulbCurrent[ix+1], dest[ix+1], lambda, delta);
                bulbCurrent[ix+2] = MathUtils.damp(bulbCurrent[ix+2], dest[ix+2], lambda, delta);
                
                dummy.position.set(bulbCurrent[ix], bulbCurrent[ix+1], bulbCurrent[ix+2]);
                dummy.scale.setScalar(isScattered ? 0.5 : 1); 
                dummy.updateMatrix();
                bulbsRef.current.setMatrixAt(i, dummy.matrix);
            }
            bulbsRef.current.instanceMatrix.needsUpdate = true;
       }
    });
    
    return (
        <group>
            <instancedMesh ref={bulbsRef} args={[undefined, undefined, bulbCount]}>
                <sphereGeometry args={[0.08, 16, 16]} />
                <meshStandardMaterial 
                    toneMapped={false} 
                    emissive="white" 
                    emissiveIntensity={2} 
                /> 
            </instancedMesh>
            <DynamicWire offset={offset} isScattered={isScattered} />
        </group>
    );
};

const DynamicWire: React.FC<{ offset: number, isScattered: boolean }> = ({ offset, isScattered }) => {
    const lineRef = useRef<any>(null);
    const scatterFactor = useRef(0);
    
    // Create initial points array
    const points = useMemo(() => {
        const arr = [];
        const turns = 7;
        const pointsPerTurn = 15;
        const totalPoints = turns * pointsPerTurn;
        for(let i=0; i<totalPoints; i++) arr.push(new Vector3(0,0,0));
        return arr;
    }, []);

    useFrame((state, delta) => {
        if (!lineRef.current) return;

        const target = isScattered ? 1 : 0;
        scatterFactor.current = MathUtils.damp(scatterFactor.current, target, 3, delta);
        
        const sf = scatterFactor.current;
        const turns = 7;
        const totalPoints = points.length;

        // Calculate points
        for(let i=0; i<totalPoints; i++) {
            const t = i / (totalPoints-1);
            const y = t * TREE_HEIGHT;
            const baseR = MathUtils.lerp(TREE_RADIUS_BASE + 0.6, 0.2, t);
            
            const expandedR = baseR * 4 + (Math.sin(t * 10) * 2);
            const currentR = MathUtils.lerp(baseR, expandedR, sf);

            const theta = t * Math.PI * 2 * turns + offset;
            const droop = Math.sin(t * turns * Math.PI * 2) * 0.1 * (1 - sf);

            points[i].set(
                currentR * Math.cos(theta),
                y - droop,
                currentR * Math.sin(theta)
            );
        }

        // Update Line Geometry
        // We use a safe check here because Drei's Line component ref might not be immediately available
        // or the structure of the geometry object might vary slightly between versions.
        if (lineRef.current && lineRef.current.geometry && typeof lineRef.current.geometry.setPositions === 'function') {
             const positions = points.map(p => [p.x, p.y, p.z]).flat();
             lineRef.current.geometry.setPositions(positions);
        }
    });

    return (
        <Line
            ref={lineRef}
            points={points} // Initial points
            color="#1a202c"
            lineWidth={2}
            transparent
            opacity={0.8}
        />
    );
}

export const Ribbons: React.FC<RibbonsProps> = ({ isScattered }) => {
  return (
    <group>
      <StringLightStrand offset={0} isScattered={isScattered} bulbCount={60} colorTheme="warm" />
      <StringLightStrand offset={Math.PI} isScattered={isScattered} bulbCount={60} colorTheme="color" />
    </group>
  );
};