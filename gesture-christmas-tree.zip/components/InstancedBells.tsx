import React, { useMemo, useRef, useEffect } from 'react';
import { InstancedMesh, Object3D, Color, MathUtils, Vector3 } from 'three';
import { useFrame } from '@react-three/fiber';
import { BELL_COUNT, TREE_HEIGHT, TREE_RADIUS_BASE, SCATTER_RADIUS } from '../constants';

interface InstancedBellsProps {
  isScattered: boolean;
}

export const InstancedBells: React.FC<InstancedBellsProps> = ({ isScattered }) => {
  const meshRef = useRef<InstancedMesh>(null);
  const dummy = useMemo(() => new Object3D(), []);
  
  // Data arrays to store positions
  const targetPositions = useMemo(() => new Float32Array(BELL_COUNT * 3), []);
  const currentPositions = useMemo(() => new Float32Array(BELL_COUNT * 3), []);
  const randomScatterPositions = useMemo(() => new Float32Array(BELL_COUNT * 3), []);
  const initialRotations = useMemo(() => new Float32Array(BELL_COUNT * 3), []);
  const bellColors = useMemo(() => new Float32Array(BELL_COUNT * 3), []);

  // Initialize positions and colors
  useEffect(() => {
    const green = new Color("#15803d"); // Deep Emerald
    const red = new Color("#b91c1c");   // Deep Red
    const gold = new Color("#d97706");  // Amber/Gold

    for (let i = 0; i < BELL_COUNT; i++) {
      // --- Tree Shape Calculation (Spiral Cone) ---
      const t = i / BELL_COUNT; 
      const y = t * TREE_HEIGHT;
      const r = MathUtils.lerp(TREE_RADIUS_BASE, 0.2, t);
      const theta = t * Math.PI * 20; 

      const x = r * Math.cos(theta);
      const z = r * Math.sin(theta);

      const noiseAmp = 0.2;
      const tx = x + (Math.random() - 0.5) * noiseAmp;
      const ty = y + (Math.random() - 0.5) * noiseAmp;
      const tz = z + (Math.random() - 0.5) * noiseAmp;

      targetPositions[i * 3] = tx;
      targetPositions[i * 3 + 1] = ty;
      targetPositions[i * 3 + 2] = tz;

      // --- Scatter Position Calculation ---
      const u = Math.random();
      const v = Math.random();
      const thetaScatter = 2 * Math.PI * u;
      const phiScatter = Math.acos(2 * v - 1);
      const rScatter = SCATTER_RADIUS * Math.cbrt(Math.random()); 

      randomScatterPositions[i * 3] = rScatter * Math.sin(phiScatter) * Math.cos(thetaScatter);
      randomScatterPositions[i * 3 + 1] = rScatter * Math.sin(phiScatter) * Math.sin(thetaScatter) + (TREE_HEIGHT / 2); 
      randomScatterPositions[i * 3 + 2] = rScatter * Math.cos(phiScatter);

      currentPositions[i * 3] = tx;
      currentPositions[i * 3 + 1] = ty;
      currentPositions[i * 3 + 2] = tz;

      // --- Rotation Randomness ---
      initialRotations[i * 3] = (Math.random() - 0.5) * 0.5;
      initialRotations[i * 3 + 1] = Math.random() * Math.PI * 2;
      initialRotations[i * 3 + 2] = (Math.random() - 0.5) * 0.5;

      // --- Colors ---
      const colorRand = Math.random();
      let c;
      if (colorRand > 0.35) c = green; // 65% Green
      else if (colorRand > 0.15) c = red; // 20% Red
      else c = gold; // 15% Gold

      bellColors[i * 3] = c.r;
      bellColors[i * 3 + 1] = c.g;
      bellColors[i * 3 + 2] = c.b;
    }

    if (meshRef.current) {
        for (let i = 0; i < BELL_COUNT; i++) {
            const color = new Color(bellColors[i*3], bellColors[i*3+1], bellColors[i*3+2]);
            meshRef.current.setColorAt(i, color);
        }
        meshRef.current.instanceColor!.needsUpdate = true;
    }
  }, [targetPositions, currentPositions, randomScatterPositions, initialRotations, bellColors, dummy]);

  // Animation Loop
  useFrame((state, delta) => {
    if (!meshRef.current) return;

    const lambda = 4; 
    const dest = isScattered ? randomScatterPositions : targetPositions;

    for (let i = 0; i < BELL_COUNT; i++) {
      const ix = i * 3;
      const iy = i * 3 + 1;
      const iz = i * 3 + 2;

      currentPositions[ix] = MathUtils.damp(currentPositions[ix], dest[ix], lambda, delta);
      currentPositions[iy] = MathUtils.damp(currentPositions[iy], dest[iy], lambda, delta);
      currentPositions[iz] = MathUtils.damp(currentPositions[iz], dest[iz], lambda, delta);

      dummy.position.set(currentPositions[ix], currentPositions[iy], currentPositions[iz]);
      
      if (isScattered) {
          dummy.rotation.set(
              initialRotations[ix] + state.clock.getElapsedTime(), 
              initialRotations[iy] + state.clock.getElapsedTime(), 
              initialRotations[iz]
          );
      } else {
          const swayX = Math.sin(state.clock.getElapsedTime() * 2 + currentPositions[ix]) * 0.1;
          const swayZ = Math.cos(state.clock.getElapsedTime() * 1.5 + currentPositions[iz]) * 0.1;
          dummy.rotation.set(swayX, initialRotations[iy], swayZ);
      }
      
      dummy.scale.setScalar(1);
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    }
    
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, BELL_COUNT]}>
      {/* Sphere Geometry for Baubles - Higher poly for better reflections */}
      <sphereGeometry args={[0.2, 48, 48]} />
      {/* High Quality Metallic Material */}
      <meshStandardMaterial 
        roughness={0.15} 
        metalness={1.0} 
        envMapIntensity={1.5}
      />
    </instancedMesh>
  );
};