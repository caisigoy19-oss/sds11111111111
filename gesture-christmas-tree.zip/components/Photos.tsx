import React, { useMemo, useRef } from 'react';
import { useTexture } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import { Group, MathUtils, Vector3 } from 'three';
import { SCATTER_RADIUS, TREE_HEIGHT, TREE_RADIUS_BASE } from '../constants';

interface PhotosProps {
  isScattered: boolean;
  photos: string[];
}

// Individual Polaroid Component
const Polaroid: React.FC<{ 
    url: string; 
    index: number; 
    total: number;
    isScattered: boolean;
}> = ({ url, index, total, isScattered }) => {
    const texture = useTexture(url);
    const groupRef = useRef<Group>(null);
    
    // Calculate Target Position (In the tree gaps)
    const targetPos = useMemo(() => {
        // Spiral placement similar to bells, but offset
        // We want them somewhat distributed along height
        const t = index / Math.max(total, 1);
        const y = t * TREE_HEIGHT * 0.8 + 1; // Keep within bulk of tree
        const r = MathUtils.lerp(TREE_RADIUS_BASE, 0.5, t) + 0.5; // Slightly further out than bells
        const theta = t * Math.PI * 10 + (Math.PI / 2); // Offset rotation

        return new Vector3(
            r * Math.cos(theta),
            y,
            r * Math.sin(theta)
        );
    }, [index, total]);

    // Calculate Scatter Position
    const scatterPos = useMemo(() => {
        const u = Math.random();
        const v = Math.random();
        const theta = 2 * Math.PI * u;
        const phi = Math.acos(2 * v - 1);
        const radius = SCATTER_RADIUS * 0.8; // Slightly closer than max bell scatter
        return new Vector3(
            radius * Math.sin(phi) * Math.cos(theta),
            radius * Math.sin(phi) * Math.sin(theta) + TREE_HEIGHT/2,
            radius * Math.cos(phi)
        );
    }, []);

    // Random rotation for natural look
    const randomRot = useMemo(() => {
        return {
            x: (Math.random() - 0.5) * 0.5,
            y: (Math.random() - 0.5) * 0.5,
            z: (Math.random() - 0.5) * 0.5
        };
    }, []);

    useFrame((state, delta) => {
        if (!groupRef.current) return;
        
        const dest = isScattered ? scatterPos : targetPos;
        const lambda = 3; // Smoothness factor

        // Smoothly move
        groupRef.current.position.x = MathUtils.damp(groupRef.current.position.x, dest.x, lambda, delta);
        groupRef.current.position.y = MathUtils.damp(groupRef.current.position.y, dest.y, lambda, delta);
        groupRef.current.position.z = MathUtils.damp(groupRef.current.position.z, dest.z, lambda, delta);

        // Rotation logic
        if (isScattered) {
            // Tumble slowly
            groupRef.current.rotation.x += delta * 0.5;
            groupRef.current.rotation.y += delta * 0.3;
        } else {
            // Return to upright-ish facing out
            // Calculate vector to center to face outward
            const angleToCenter = Math.atan2(groupRef.current.position.x, groupRef.current.position.z);
            
            // Damp rotation to target orientation
            // We want the photo to face roughly outwards + some random sway
            const targetRotY = angleToCenter + randomRot.y;
            
            groupRef.current.rotation.x = MathUtils.damp(groupRef.current.rotation.x, randomRot.x, lambda, delta);
            groupRef.current.rotation.y = MathUtils.damp(groupRef.current.rotation.y, targetRotY, lambda, delta);
            groupRef.current.rotation.z = MathUtils.damp(groupRef.current.rotation.z, randomRot.z, lambda, delta);
        }
    });

    return (
        <group ref={groupRef} scale={1.5}>
            {/* White Border Card */}
            <mesh position={[0, 0, 0]}>
                <boxGeometry args={[1, 1.2, 0.05]} />
                <meshStandardMaterial color="#fdfbf7" roughness={0.8} />
            </mesh>
            {/* Photo Texture */}
            <mesh position={[0, 0.1, 0.03]}>
                <planeGeometry args={[0.8, 0.8]} />
                <meshBasicMaterial map={texture} />
            </mesh>
        </group>
    );
};

export const Photos: React.FC<PhotosProps> = ({ isScattered, photos }) => {
  return (
    <group>
        {photos.map((url, index) => (
            <Polaroid 
                key={url} 
                url={url} 
                index={index} 
                total={photos.length} 
                isScattered={isScattered} 
            />
        ))}
    </group>
  );
};