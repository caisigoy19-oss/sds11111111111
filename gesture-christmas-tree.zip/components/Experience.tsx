import React, { useRef } from 'react';
import { OrbitControls, Stars, Environment, Sparkles } from '@react-three/drei';
import { EffectComposer, Bloom } from '@react-three/postprocessing';
import { InstancedBells } from './InstancedBells';
import { Ribbons } from './Ribbons';
import { Photos } from './Photos';
import { useFrame } from '@react-three/fiber';
import { Group } from 'three';

interface ExperienceProps {
  isScattered: boolean;
  photos: string[];
}

export const Experience: React.FC<ExperienceProps> = ({ isScattered, photos }) => {
  const groupRef = useRef<Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
        // Slowly rotate the whole tree for presentation
        if (!isScattered) {
            groupRef.current.rotation.y += 0.002;
        } else {
             // Slower rotation when scattered
            groupRef.current.rotation.y += 0.0005;
        }
    }
  });

  return (
    <>
      <color attach="background" args={['#02040a']} />
      
      {/* High Quality Lighting */}
      <ambientLight intensity={0.2} />
      <spotLight 
        position={[10, 20, 10]} 
        angle={0.3} 
        penumbra={1} 
        intensity={3} 
        castShadow 
        color="#fff5d6" 
      />
      {/* Rim lights for metallic effect */}
      <pointLight position={[-10, 0, -10]} intensity={2} color="#4f46e5" distance={30} />
      <pointLight position={[10, 5, 10]} intensity={2} color="#ef4444" distance={30} />
      
      {/* Night City Environment for reflections */}
      <Environment preset="city" />
      
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      
      {/* Glowing particles in background */}
      <Sparkles count={150} scale={15} size={3} speed={0.4} opacity={0.6} color="#fbbf24" />

      <group ref={groupRef} position={[0, -4, 0]}>
        <InstancedBells isScattered={isScattered} />
        <Ribbons isScattered={isScattered} />
        <Photos isScattered={isScattered} photos={photos} />
      </group>

      <OrbitControls 
        enablePan={false} 
        enableZoom={true} 
        minPolarAngle={Math.PI / 4} 
        maxPolarAngle={Math.PI / 1.5}
        minDistance={10}
        maxDistance={30}
      />

      {/* Post Processing for Glow */}
      <EffectComposer disableNormalPass>
        <Bloom 
            luminanceThreshold={1.2} 
            mipmapBlur 
            intensity={1.5} 
            radius={0.6} 
        />
      </EffectComposer>
    </>
  );
};